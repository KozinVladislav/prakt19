<?php
header('Content-Type: text/html; charset=utf-8');
session_start();
error_reporting(0);

include "engine/connection.php";
include "engine/array.php";

if($_SESSION['htmlhack'] || $_SESSION['sqlhack']) {
    include "block.php";
}

$types = array("image/jpg" , "image/png" , "image/jpeg" , "image/bmp");
if(isset($_FILES['avatar']) and $_FILES['avatar']['size'] > 0 and in_array($_FILES['avatar']['type'] , $types))
{
	$path = "images/";
	$filename = rand(1000,10000) . $_FILES['avatar']['name'];
	$fullname = $path . $filename;
	$tmp_name = $_FILES['avatar']['tmp_name'];
	move_uploaded_file($tmp_name , $fullname);
	$connect->query("UPDATE `user` SET `avatar` = '$fullname' WHERE `login` = '$login'");
}


$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$login';");
$row = $query->fetch_assoc();

$id = $row['id'];
$name = $row['name'];
$surname = $row['surname'];
$login = $row['login'];
$email = $row['email'];
$password = $row['password'];
$repeatPassword = $row['repeatPassword'];

if (isset($_POST['subm'])) {
	$name = htmlspecialchars($name);
	$surname = htmlspecialchars($surname);	
	$login = htmlspecialchars($login);
	$email = htmlspecialchars($email); 

	$sub = [

		'sub1' => 0,
		'sub2' => 0,
		'sub3' => 0

	];

	if (is_array($_POST['sub']))
		foreach ($_POST['sub'] as $s)
			$sub[$s] = 1;

		$flag = false;

	if (!empty($_POST['password']) && !empty($_POST['repeatPassword'])) {
		$flag = true;
		echo "flag =true";
		$valueSalt = $connect->query("SELECT `id` FROM `user` WHERE `id` = '$id'; ");		
		$valueSalt = $valueSalt->fetch_assoc();
		foreach ($valueSalt as $key => $value) {
			$valueSalt = $value;
		}
		$idSalt = pow($valueSalt, 3); 
		$password = sha1(sha1(htmlspecialchars($_POST['password']) . $idSalt));
		$repeatPassword = sha1(sha1(htmlspecialchars($_POST['repeatPassword']) . $idSalt));
		if ($password != $repeatPassword) die('поля Пароль и Повтор пароля не совпадают'); 
	}	

		$pas = ($flag) ? $password : $row['password'];
		$repeatPass = ($flag) ? $password : $row['password'];
		
		$connect->query("UPDATE user SET name = '$name',
								surname 		= '$surname',
								email 			= '$email',
								password 		= '$pas',
								repeatPassword 	= '$repeatPass',
								sub1 			= '" . $sub['sub1'] . "',
								sub2 			= '" . $sub['sub2'] . "',
								sub3 			= '" . $sub['sub3'] . "'	
								WHERE id = $id; ");

	} 


$connect->close();
header("Location: private_office.php");