<?php
session_start();
error_reporting(0);

if($_SESSION['auth']) {
	header("Location: private_office.php");
}

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Регистрация</title>
<link rel="stylesheet" type="text/css" href="css/css.css">
</head>
<body id="wrapper">
<div class="block_links">
		<a href="activatoin.php">Авторизация</a>
</div>
<form id="log" action="registration.php" method="post">
<h2> Регистрация </h2>
<hr><br>
<label for="name">Имя</label><br>
<input type="text" name="name" id="name"  maxlength="10"  placeholder="Андрей1998" required="required" name="Имя"><br>
<label for="surname">Фамилия</label><br>
<input type="text" name="surname" id="surname" placeholder="Иванов" ><br>
<label for="login">Логин</label><br>
<input type="text" name="login" id="login"  placeholder="sambuka" ><br>
<label for="email">email</label><br>
<input type="email" name="email" id="email" placeholder="ivanov@mail.ru" ><br>
<label for="password">Пароль</label><br>
<input type="password" name="password"  id="password"  maxlength="10" placeholder="qwertyA$" ><br>
<label for="repeatPassword">Повтор пароля</label><br>
<input type="password" name="repeatPassword" id="repeatPassword"  maxlength="10" placeholder="qwertyA$"><br>

<label for="news"><input class="checkbox-custom" type="checkbox" id="news" 	  name="sub[]" value = "Новости"> Подписка на новости</label><br>
<label for="shares"><input class="checkbox-custom" type="checkbox" id="shares"  name="sub[]" value = "Акции"> Подписка на акции</label><br>
<label for="groups"><input class="checkbox-custom" type="checkbox" id="groups"  name="sub[]" value = "Мероприятия"> Подписка на мероприятия</label><br>

<p class="signin button"><br>
<input type="submit" name="submit" value="Регистрация"></p>

</form>

</body>
</html>
