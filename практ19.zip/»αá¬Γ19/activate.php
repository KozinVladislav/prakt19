<?php
session_start();
error_reporting(0);
if($_SESSION['htmlhack'] || $_SESSION['sqlhack']) {
    include "block.php";
}
include_once "engine/connection.php";
$login = htmlspecialchars($_POST['login']);

	if($login != $connect->escape_string($login)) {
	    $_SESSION['sqlhack'] = true;
	    $_SESSION['timeout'] = date("i");
	    $login = htmlspecialchars($login);
	    die("Попытка sql атаки!");
	}

	if($login != htmlspecialchars($login)) {
	    $_SESSION['htmlhack'] = true;
	    $_SESSION['timeout'] = date("i");
	    $login = htmlspecialchars($login);
	    die("Попытка html атаки!");
	}

if (isset($_POST['submit']))
{
	$valueSalt = $connect->query("SELECT `id`, `password` FROM `user` WHERE `login` = '$login'; ");		
	$valueSalt = $valueSalt->fetch_assoc(); 
	$idSalt = pow($valueSalt['id'], 3); 
	$password = $valueSalt['password'];
	$enterPassword = sha1(sha1($_POST['password'] . $idSalt));

    if($password == $enterPassword) {
		$_SESSION['auth'] = true;
    	$_SESSION['login'] = $login;
		header("Location: private_office.php");
	}	else die('<br>Неверный ввод логина или пароля');
}
	
