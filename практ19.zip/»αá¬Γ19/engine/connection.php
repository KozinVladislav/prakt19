<?php

header('Content-type: text/html; charset=utf-8');
$config = file_get_contents("config.txt"); // Читает содержимое файла в строку
$config = explode(':' , $config); // Разбивает строку с помощью разделителя
$config = implode("|" , $config); // Объединяет элементы массива в строку
$config = explode('|' , $config);
/* 1й 2й 3й 4й 5й 7й 9й элементы массива имеют соответствующие значения: localhost root  pract /images */
$connect = new mysqli($config[1] , $config[3] , $config[5] , $config[7]);

if ($connect->connect_error) {
    die('Error : ('. $connect->connect_errno .') '. $connect->connect_error);
}
$connect->set_charset('utf8');	
