<?php 	
header('Content-Type: text/html; charset=utf-8');
session_start();
error_reporting(0);

if($_SESSION['htmlhack'] || $_SESSION['sqlhack']) {
    include "block.php";
}

if (isset($_POST['submit'])) 
{
	require_once "engine/function.php";
	require_once "engine/array.php";

	$name = htmlspecialchars($name);
	$surname = htmlspecialchars($surname);	
	$login = htmlspecialchars($login);
	$email = htmlspecialchars($email); 
	$password = htmlspecialchars($password);
	$repeatPassword = htmlspecialchars($repeatPassword); 

	require_once "engine/connection.php";

	if($login != $connect->escape_string($login)) {
		$_SESSION['sqlhack'] = true;
		$_SESSION['timeout'] = date("i");
		$login = htmlspecialchars($login);
		die("Попытка sql атаки!");
	}

	if($login != htmlspecialchars($login)) {
		$_SESSION['htmlhack'] = true;
		$_SESSION['timeout'] = date("i");
		$login = htmlspecialchars($login);
		die("Попытка html атаки!");
	}

	$checklogin = $connect->query("SELECT login FROM user WHERE login = '$login';");
	$check = $checklogin->fetch_assoc();
	if (!empty($check['login'])) {
		die("Пользователь с таким логином уже существует!");
	}


	$checkEmail = $connect->query("SELECT email FROM user WHERE email = '$email';");
	$check = $checkEmail->fetch_assoc();	
	if(!empty($check['email']))	{
		die("Пользователь с такой почтой уже существует!");
	}

		$chekcSalt = $connect->query("SELECT MAX(id) AS `id` FROM `user`; ");
		$chekcSalt = $chekcSalt->fetch_assoc(); 
		if (empty($chekcSalt)) {
			$idSalt = 1;
		} else {
			foreach ($chekcSalt as $key => $value) {
				$idSalt = pow(($value + 1), 3);
			} 
		}

		$password = sha1(sha1($password . $idSalt));
		$repeatPassword = $password;

		$res = $connect->query("INSERT INTO `user` (`name`, `surname`, `login`, `email`, `password`, `repeatPassword`,`sub1`, `sub2`, `sub3` , `avatar`) VALUES ('$name', '$surname', '$login', '$email', '$password', '$repeatPassword' , '$news', '$shares', '$groups' , 'no_photo.jpg');");

		$connect->close();	
		$_SESSION['auth'] = true;
		$_SESSION['login'] = $login;
		header("Location: private_office.php");

	} else die ('Поля "Пароль" и "Повтор пароля" не совпадают');


