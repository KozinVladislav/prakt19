<?php
session_start();
error_reporting(0);
if($_SESSION['auth']) {
    header("Location: private_office.php");
}

if($_SESSION['htmlhack'] || $_SESSION['sqlhack'])
{
    include "block.php";
}

?>

<!DOCTYPE html>	
<html>
<head>
<meta charset="UTF-8">
<title>Авторизация </title>
<link rel="stylesheet" type="text/css" href="css/css.css">
</head>
<body id="wrapper">
<div class="block_links">
	<a href="index.php">Регистрация</a>
</div>
<form id="log" action="activate.php" method="post">
<h2> Авторизация </h2>
<label for="login">Логин</label><br>
<input type="text" name="login" required><br>
<label for="password">Пароль</label><br>
<input type="password" name="password"  id="password"  maxlength="20"  required><br>

<p class="signin button"><br>
<input type="submit" name="submit" value="Войти"></p>	

</form>


</body>
</html>
