<?php
session_start();
error_reporting(0);
$login = $_SESSION['login'];

if(!$_SESSION['auth'])
{
    header("Location: index.php");
}

include "engine/connection.php";
$res = $connect->query("SELECT * FROM `user` WHERE `login` = '$login';");
$row = $res->fetch_assoc();
$id = $row['id'];

$sub_checked = [

			'sub1' => ($row['sub1'] == '1') ? 'checked' : '',
			'sub2' => ($row['sub2'] == '1') ? 'checked' : '',
			'sub3' => ($row['sub3'] == '1') ? 'checked' : ''

		];

$_SESSION['timeout'] = date('i');

?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Личный кабинет</title>
<link rel="stylesheet" type="text/css" href="css/css.css">
<script src="http://code.jquery.com/jquery-latest.js"></script>
<?include_once "private.php";?>

</head>
<body id="wrapper">

<form enctype="multipart/form-data" id="log" action="private.php"  method="post">
<h2> Личный кабинет </h2>
<hr><br>
<label for="avatar">Аватар</label><br>
<img src="<?=$row['avatar']?>" height="200" width="200"><br>
<input type="hidden" name="MAX_FILE_SIZE" value="10000000">
Загрузить аватар: <input name="avatar" type="file" accept="image/*"><br>
<label for="name">Имя</label><br>
<input type="text" name="name" id="name"  maxlength="20"  placeholder="Андрей1998" required="required" name="Имя" value="<?= $row['name']; ?>";><br>
<label for="surname">Фамилия</label><br>
<input type="text" name="surname" id="surname" placeholder="Иванов" required="required" value="<?=$row['surname']; ?>"><br>
<label for="login">Логин</label><br>
<input readonly type="text" name="login" id="login1"  placeholder="sambuka" value="<?=$row['login']; ?>" ><br>
<label for="email">email</label><br>
<input type="email" name="email" id="email" placeholder="ivanov@mail.ru" required="required" value="<?=$row['email']; ?>"><br>
<label for="password">Пароль</label><br>
<input type="password" name="password"  id="password"  maxlength="20" placeholder="qwertyA$" value=""><br>
<label for="repeatPassword">Повтор пароля</label><br>
<input type="password" name="repeatPassword" id="repeatPassword"  maxlength="10" placeholder="qwertyA$" value=""><br>
		
<label for="sub1"> <input <?=$sub_checked['sub1'];?> class="checkbox-custom" type="checkbox"  name="sub[]"  value="sub1"> Подписка на новости</label><br>
<label for="sub2"> <input <?=$sub_checked['sub2'];?> class="checkbox-custom" type="checkbox"  name="sub[]"  value="sub2"> Подписка на акции</label><br>
<label for="sub3"> <input <?=$sub_checked['sub3'];?> class="checkbox-custom" type="checkbox"  name="sub[]"  value="sub3"> Подписка на мероприятия</label><br>

<p class="signin button"><br>
<input type="submit" name="subm"  value="Сохранить"></p>
<a href="logout.php">Выйти</a>

</form>


</body>
</html>
