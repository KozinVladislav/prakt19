<?php
include_once "function.php";

$name = test('name', 'имени', "/[A-Za-zА-Яа-яЁё0-9]{2,10}/u"); 
$surname = test('surname', 'фамилии', "/[A-Za-zА-Яа-яЁё]{2,14}/u");	
$login = test('login', 'логина', "/.{3,14}?/u");
$email = test('email', 'почты', "/[@]/u");
$password = test('password', 'пароля', "/(?=.*[A-Z]{1,})(?=.*\W{1}).{5,10}/u");
$repeatPassword = test('repeatPassword', 'повтора пароля', "/(?=.*[A-Z]{1,})(?=.*\W{1}).{5,10}/u");
$news = testSub('Новости');
$shares = testSub('Акции');
$groups = testSub('Мероприятия');	