<?php 
	require_once "engine/connection.php";

		$val  = $connect->query("SELECT MAX(id) AS `id` FROM `user`; ") ;
		$val = $val->fetch_assoc();
		var_dump($val);
		foreach ($val as $key => $value) {
			$salt = pow(($value + 1), 3);
				
		}
		echo $salt;